import React from 'react';
import ChainSelector from './ChainSelector';

const ChainSelectorWrapper = ({
  openChainSelector,
  setOpenChainSelector,
  openChainSelectorModal,
  receiveChains,
  suppliesChain,
  setSuppliesChain,
}) => {
  // ... existing ChainSelectorWrapper code
};

export default ChainSelectorWrapper;
