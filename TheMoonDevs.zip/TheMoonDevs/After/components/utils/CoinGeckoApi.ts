import CoinGeckoApi from './utils/CoinGeckoApi';

// ... existing CoinGeckoApi code
