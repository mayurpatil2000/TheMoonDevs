import ChainScanner from './utils/ChainScanner';

// ... existing ChainScanner code
