import React from 'react';
import AppToast from './AppToast';

const AppToastWrapper = ({ toastMsg, toastSev }) => {
  // ... existing AppToastWrapper code
};

export default AppToastWrapper;
