import React from 'react';
import DashboardLayoutStyled from './DashboardLayoutStyled';

const DashboardLayoutStyledWrapper = ({ children }) => {
  // ... existing DashboardLayoutStyledWrapper code
};

export default DashboardLayoutStyledWrapper;
