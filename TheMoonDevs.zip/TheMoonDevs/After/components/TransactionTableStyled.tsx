import React from 'react';
import BurnTxTable from './BurnTxTable';

const TransactionTableStyled = ({ burnTransactions, coinData }) => {
  // ... existing TransactionTableStyled code
};

export default TransactionTableStyled;
