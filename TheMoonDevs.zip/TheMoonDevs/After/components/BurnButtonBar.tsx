import React from 'react';
import { Button, CircularProgress } from '@material-ui/core';
import AppIcon from './AppIcon';
import AppExtLink from './AppExtLink';
import AppTooltip from './AppTooltip';
import { BurnTxProgress } from './enums';
import { parseEther } from 'ethers/utils';

const BurnButtonBar = ({
  burnAmount,
  onChangeBurnAmount,
  executeBurn,
  txProgress,
  txButton,
  burnTxHash,
  walletChain,
}) => {
  // ... existing BurnButtonBar code
};

export default BurnButtonBar;
