# BurnPage Refactoring

This repository contains the refactored BurnPage, which has been fragmented into smaller, more maintainable components. The refactored code can be found in the `after` folder, while the original code is in the `before` folder for comparison.

## Justification

The original BurnPage code contained a lot of UI and functionality in a single file, making it hard to read and maintain. By fragmenting the UI into selective components, we improve readability, maintainability, and reusability.

## Folder Structure

* `components`: Contains the smaller, reusable components extracted from the original BurnPage.
* `BurnPage.tsx`: The main entry point for the BurnPage, which imports and uses the components from the `components` folder.

## Components

* `BurnButtonBar`: Encapsulates the Burn button and input field for entering the amount to burn.
* `BurnStatsContainer`: Displays the supply statistics, including burnt and circulating tokens.
* `ChainSelector`: Allows users to switch the token chain.
* `TransactionTableStyled`: Renders the Burn transactions table.